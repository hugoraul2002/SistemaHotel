import React from 'react';
import { Sidebar } from 'primereact/sidebar';
import { Button } from 'primereact/button';
import { Avatar } from 'primereact/avatar';
import { Menu } from 'primereact/menu';

export default function BarraLateral({ visible, setVisible }: { visible: boolean, setVisible: React.Dispatch<React.SetStateAction<boolean>> }) {
    const customIcons = (
        <>
            <button className="p-sidebar-icon p-link mr-2">
                <span className="pi pi-search" />
            </button>
        </>
    );

    const customHeader = (
        <div className="flex align-items-center gap-2">
            <Avatar image="https://primefaces.org/cdn/primereact/images/avatar/amyelsner.png" shape="circle" />
            <span className="font-bold">Amy Elsner</span>
        </div>
    );

    const items = [
        { label: 'Clientes', icon: 'pi pi-users' },
        { label: 'Reservaciones', icon: 'pi pi-calendar' },
        { label: 'Recepción', icon: 'pi pi-sign-in' },
        { label: 'Salidas', icon: 'pi pi-sign-out' },
        { label: 'Facturación', icon: 'pi pi-file' },
        { label: 'Gastos', icon: 'pi pi-money-bill' },
        { label: 'Cajas', icon: 'pi pi-box' },
        {
            label: 'Reportes', icon: 'pi pi-chart-line', items: [
                { label: 'Reporte de Ventas', icon: 'pi pi-file' },
                { label: 'Reporte de Gastos', icon: 'pi pi-file' }
            ]
        },
        { label: 'Usuarios', icon: 'pi pi-user' },
        { label: 'Configuración', icon: 'pi pi-cog' },
        { label: 'Salir', icon: 'pi pi-sign-out' }
    ];

    return (
        <div className="card flex justify-content-center">
            <Sidebar header={customHeader} visible={visible} onHide={() => setVisible(false)} icons={customIcons}>
                <Menu model={items}  className='w-full md:w-15rem'/>
            </Sidebar>
            <Button icon="pi pi-bars" onClick={() => setVisible(true)} />
        </div>
    );
}
