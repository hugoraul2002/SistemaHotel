import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { useState } from 'react';
import './App.css';
import Login from './pages/Autenticacion/Login';
import { Inicio } from './pages/Inicio';
import Register from './pages/Autenticacion/Register';
import Navbar from './components/Navbar';
import BarraLateral from './components/Sidebar';

function App() {
  const [visible, setVisible] = useState(false);

  return (
    <BrowserRouter>
      <Navbar visible={visible} setVisible={setVisible} />
      <BarraLateral visible={visible} setVisible={setVisible} />
      <Routes>
        <Route path='/' element={<Login />} />
        <Route path='/register' element={<Register />} />
        <Route path='/Inicio' element={<Inicio />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

