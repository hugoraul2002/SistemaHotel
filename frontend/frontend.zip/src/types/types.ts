export interface Usuario {
    id: number;
    full_name: string;
    email: string;
    password: string;
  }