import UsuarioPage from './UsuarioPage';
export const Inicio: React.FC = () => {
    
    return (
        <>
            <UsuarioPage />
            {/* <SidebarG visible={visible} setVisible={setVisible}/> */}
        </>

    );
};